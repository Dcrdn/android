package com.example.t_dicard.read;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.FileObserver;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final Integer FILES = 0x1;

    public MainActivity(){
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private void askForPermission(String permission, Integer requestCode) {

        if (ContextCompat.checkSelfPermission(MainActivity.this, permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, permission)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{permission}, requestCode);
            }else{
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{permission}, requestCode);
            }
        } else { //Here I know I have my permissions
            Toast.makeText(this, "" + permission + " is granted. ", Toast.LENGTH_SHORT).show();
            //now lets print on console the files
            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            String path = directory.getAbsolutePath();
            Log.i("Path: ", path);
            File[] listFiles= directory.listFiles();
            Log.i("Size", listFiles.length+"");
            for(int i=0;i<listFiles.length;i++){
                Log.i("Name: ", listFiles[i].getName());
            }
        }
    }

    public void ask(View v){
        switch (v.getId()){
            case R.id.files:
                askForPermission(Manifest.permission.READ_EXTERNAL_STORAGE, this.FILES);
        }
    }
}
